<?php

$con = mysqli_connect("localhost","root","","project_showcase_management");

if(!$con){
    die('connection Faield'.mysqli_connect_error());
}


?>