<?php

 

$connect = new PDO("mysql:host=localhost;dbname=add_fec", "root", "");

?>