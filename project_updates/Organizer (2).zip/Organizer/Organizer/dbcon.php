<?php

$con = mysqli_connect("localhost","root","","project_showcase");

if(!$con){
    die('connection Faield'.mysqli_connect_error());
}
else{
    echo "SUccessful connection";
}

?>