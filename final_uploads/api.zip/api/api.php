<?php

	$id = $_GET['id'];

	error_reporting(0);
	$link = mysqli_connect("localhost", "root", "", "t0");
	
	$status = 'OK';
	$content = [];

	if (mysqli_connect_errno()) {
		$status = 'ERROR';
		$content = mysqli_connect_error();
	}

	$query = "SELECT * FROM t0 WHERE id=$id";

	if ($result = mysqli_query($link, $query)) {
	/* fetch associative array */
	while ($row = mysqli_fetch_assoc($result)) {
		$content[] = $row; // push value to array
		}
	}

	$data = ["status" => $status, "content" => $content];
    //header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Origin: *');
	header('Content-type: application/json');
	echo json_encode($data); // get all products in json format.
?>